<?php get_header(); ?>

<?php get_sidebar(); ?>
    
    <div id="content">
    
		<div class="post">
        
        <h1>That Page Isn't Here</h1>
        
        <p>We're sorry, but that page isn't here. You can try going back, using the search form above, or going <a href="<?php bloginfo('url'); ?>">home</a> and starting over.</p>
        
        </div>
    
    </div><!--/content -->

<?php get_footer(); ?>