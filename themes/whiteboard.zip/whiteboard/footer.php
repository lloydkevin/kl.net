<p>
 <a href="<?php bloginfo('rss2_url'); ?>">Entries (RSS)</a> and <a href="<?php bloginfo('comments_rss2_url'); ?>">Comments (RSS)</a>
</p>
<p>
 <?php bloginfo('name'); ?> is proudly powered by <a href="http://wordpress.org/">WordPress.org</a> <!-- It is recommended that you leave this link. Links such as these are Wordpress' main form of advertising. -->
</p>
<p>
 Theme derived from <a href="http://brianpurkiss.com/"><strong>brian</strong>purkiss'</a> <a href="http://plainbeta.com/whiteboard/">whiteboard</a> <!-- You may remove these links. Though, I would appreciate it if you left them or gave me a link somewhere... -->
</p>

<?php wp_footer(); ?>
</body></html>