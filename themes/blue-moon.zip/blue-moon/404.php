<?php get_header();?>

<div id="content">
<h1>Error 404</h1>
  <h2 class="entrytitle">The page you requested is no longer here! </h2>
  <p>Instead, visit the <a href="<?php bloginfo('siteurl');?>">Home Page</a></p>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>
