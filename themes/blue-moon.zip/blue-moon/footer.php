<div id="footer">
  <p> Copyright &copy;&nbsp;<?php echo date('Y'); ?> <?php bloginfo('name'); ?><br>
    Powered by <a href="http://www.wordpress.org" title="Wordpress CMS">WordPress</a> | Designed by <a href="http://wpzone.net">Stephen Reinhardt</a><br><a href="http://hostpapa.com/cgi-bin/affiliates/clickthru.cgi?id=stephen522" target="_blank">HostPapa - Unlimited Hosting</a></p>
</div>
</div>
<?php do_action('wp_footer'); ?>
</body></html>