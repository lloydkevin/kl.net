This is a really easy installation..

1. Upload theme files to /wp-content/themes
2. In your admin, go to "Presentation" and activate "Blue Moon."


TWo features to make the theme work well for you..

1. Widget support. Go to http://automattic.com/code/widgets and install this plugin and activate. Then go to "presentation" tab and there should be a "sidebar widgets" link.

2. Admin Comment Highlighting. There's a tweak in the code to make it so that if you (admin of the site) post a comment in reply to someone else's, it will have a marker on the comment block on the site to make your comment stand out from the others. To make this work for you, you need to edit one file. Open comments.php and on line approx. 28 you'll find EMAIL@YOURDOMAIN.COM. Change this to the email address you're using for WordPress. All done!

questions..

www.vaguedream.com
www.vaguedream.com/wordpress-themes